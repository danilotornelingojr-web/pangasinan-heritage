import Button from '../atoms/Button';
import Image from '../atoms/Image';

export default function HeritageCard({ title, description, image, href = '#' }) {
  return (
    <article className="card">
      <Image src={image} alt="" />
      <div className="cardBody">
        <h3>{title}</h3>
        <p>{description}</p>
        <Button href={href} ariaLabel={`Explore ${title}`}>Explore</Button>
      </div>
    </article>
  );
}
