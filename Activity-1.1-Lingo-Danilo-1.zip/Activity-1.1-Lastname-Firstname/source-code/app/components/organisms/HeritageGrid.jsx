import HeritageCard from '../molecules/HeritageCard';

const sites = [
  { title:'Hundred Islands', description:'A landmark island group in Alaminos known for its distinctive limestone formations.', image:'/hundred-islands.svg' },
  { title:'Bolinao Lighthouse', description:'A historic coastal landmark overlooking the sea in Bolinao.', image:'/bolinao-lighthouse.svg' },
  { title:'Balungao Hot Spring', description:'A natural attraction in Balungao associated with relaxing hot spring experiences.', image:'/balungao-hot-spring.svg' },
];

export default function HeritageGrid() {
  return (
    <section id="heritage" className="section" aria-labelledby="heritage-title">
      <h2 id="heritage-title">Featured heritage destinations</h2>
      <div className="grid">
        {sites.map((site) => <HeritageCard key={site.title} {...site} />)}
      </div>
    </section>
  );
}
